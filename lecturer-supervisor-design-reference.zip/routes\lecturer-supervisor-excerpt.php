﻿<?php

// Lecturer/supervisor route groups extracted from routes/web.php.
// Reference excerpt only; imports and unrelated routes are omitted.

Route::middleware('auth:lecturer')->group(function () {
    Route::get('/lecturer/dashboard', [LecturerController::class, 'dashboard']);
    Route::get('/lecturer/students/{id}', [LecturerStudentController::class, 'show'])->whereNumber('id');
    Route::get('/lecturer/students/{id}/message', [LecturerStudentController::class, 'message'])->whereNumber('id');
    Route::redirect('/lecturer/logbook', '/lecturer/dashboard');
    Route::get('/lecturer/logbook/{id}', [LecturerStudentController::class, 'entry'])->whereNumber('id');
    Route::get('/lecturer/messages', [LecturerMessageController::class, 'index'])->name('lecturer.messages.index');
    Route::get('/lecturer/messages/{conversation}', [LecturerMessageController::class, 'show'])->name('lecturer.messages.show');
    Route::post('/lecturer/messages/{conversation}', [LecturerMessageController::class, 'store'])->name('lecturer.messages.store');
});

Route::middleware('auth:supervisor')->group(function () {
    Route::get('/supervisor/password', [SupervisorController::class, 'showPassword']);
    Route::post('/supervisor/password', [SupervisorController::class, 'updatePassword']);
});

Route::middleware(['auth:supervisor', EnsureSupervisorPasswordChanged::class])->group(function () {
    Route::get('/supervisor/dashboard', [SupervisorController::class, 'dashboard']);
    Route::get('/supervisor/logbook', [SupervisorReviewController::class, 'next']);
    Route::get('/supervisor/logbook/{id}', [SupervisorReviewController::class, 'show'])->whereNumber('id');
    Route::post('/supervisor/logbook/{id}/review', [SupervisorReviewController::class, 'store'])->whereNumber('id');
    Route::get('/supervisor/messages', [SupervisorMessageController::class, 'index'])->name('supervisor.messages.index');
    Route::get('/supervisor/messages/with/{student}', [SupervisorMessageController::class, 'start'])->whereNumber('student')->name('supervisor.messages.start');
    Route::get('/supervisor/messages/{conversation}', [SupervisorMessageController::class, 'show'])->whereNumber('conversation')->name('supervisor.messages.show');
    Route::post('/supervisor/messages/{conversation}', [SupervisorMessageController::class, 'store'])->whereNumber('conversation')->name('supervisor.messages.store');
    Route::get('/supervisor/tasks', [SupervisorTaskController::class, 'index']);
    Route::post('/supervisor/tasks', [SupervisorTaskController::class, 'store']);
    Route::put('/supervisor/tasks/{id}', [SupervisorTaskController::class, 'update'])->whereNumber('id');
    Route::delete('/supervisor/tasks/{id}', [SupervisorTaskController::class, 'destroy'])->whereNumber('id');
});
