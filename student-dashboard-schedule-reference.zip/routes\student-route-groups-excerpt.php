﻿<?php

// Student route groups extracted from routes/web.php.
// Reference excerpt only; imports and unrelated routes are omitted.

Route::middleware('auth:student')->group(function () {
    Route::post('/student/logbook/ai-help', [LogbookController::class, 'aiHelp'])->middleware(['throttle:5,1', LimitAiHelp::class]);
    Route::get('/student/dashboard', [StudentDashboardController::class, 'index']);
    Route::get('/student/logbooks', [StudentDashboardController::class, 'logbooks']);
    Route::post('/student/logbook/store', [LogbookController::class, 'store']);
    Route::post('/student/logbook/ai-help', [LogbookController::class, 'aiHelp'])->middleware('throttle:5,1');
    Route::get('/student/logbook/edit/{id}', [StudentLogbookEditController::class, 'edit'])->whereNumber('id');
    Route::post('/student/logbook/update/{id}', [StudentLogbookEditController::class, 'update'])->whereNumber('id');
    Route::get('/student/logbook/delete/{id}', [LogbookController::class, 'destroy']);
    Route::get('/student/feedback', [StudentController::class, 'feedback']);

    Route::get('/student/calendar', [StudentCalendarController::class, 'index']);

    Route::get('/student/attendance', [StudentAttendanceController::class, 'index']);
    Route::post('/student/attendance/clock-in', [StudentAttendanceController::class, 'clockIn']);
    Route::post('/student/attendance/clock-out', [StudentAttendanceController::class, 'clockOut']);
    Route::post('/student/attendance/day-off', [StudentAttendanceController::class, 'dayOff']);
    Route::post('/student/attendance/day-off/{id}/cancel', [StudentAttendanceController::class, 'cancelDayOff'])->whereNumber('id');
    
    Route::post('/student/todos', [StudentTodoController::class, 'store']);
    Route::post('/student/todos/{id}/toggle', [StudentTodoController::class, 'toggle'])->whereNumber('id');
    Route::delete('/student/todos/{id}', [StudentTodoController::class, 'destroy'])->whereNumber('id');

    Route::get('/student/messages', [StudentMessageController::class, 'index'])->name('student.messages.index');
    Route::post('/student/messages', [StudentMessageController::class, 'store'])->name('student.messages.store');
    Route::get('/student/messages/supervisor', [StudentMessageController::class, 'supervisorIndex'])->name('student.messages.supervisor');
    Route::post('/student/messages/supervisor', [StudentMessageController::class, 'supervisorStore'])->name('student.messages.supervisor.store');

    Route::get('/student/dashboard/reminders', [StudentReminderController::class, 'index']);
    Route::post('/student/dashboard/working-days', [StudentScheduleController::class, 'update']);
});

Route::middleware('auth:student,lecturer,supervisor')->group(function () {
    Route::post('/student/logbook/ai-help', [LogbookController::class, 'aiHelp'])->middleware(['throttle:5,1', LimitAiHelp::class]);
    Route::post('/conversations/{conversation}/messages/{message}/delete-for-me', [MessageDeleteController::class, 'deleteForMe'])->name('messages.delete.for.me');
    Route::post('/conversations/{conversation}/messages/{message}/delete-for-everyone', [MessageDeleteController::class, 'deleteForEveryone'])->name('messages.delete.for.everyone');
    // Route::get('/student/reminders', [StudentReminderController::class, 'index']);
    // Route::post('/student/working-days', [StudentScheduleController::class, 'update']);
    Route::post('/conversations/{conversation}/messages', [\App\Http\Controllers\ChatController::class, 'store'])
    ->whereNumber('conversation')->middleware('throttle:60,1')->name('chat.store');
Route::get('/conversations/{conversation}/messages', [\App\Http\Controllers\ChatController::class, 'since'])
    ->whereNumber('conversation')->name('chat.since');
Route::post('/conversations/{conversation}/read', [\App\Http\Controllers\ChatController::class, 'read'])
    ->whereNumber('conversation')->name('chat.read');
});
