@extends('layouts.app')

@section('content')
<div class="space-y-6">
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h2 class="text-2xl font-bold text-slate-800">Student Management</h2>
            <p class="mt-2 text-sm text-slate-500">View, edit and remove student records, reviewers and internship dates.</p>
        </div>
        <a href="/admin/students/create" class="inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700">
            Add Student
        </a>
    </div>

    @if(session('success'))
        <div class="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">{{ session('success') }}</div>
    @endif

    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-sm">
                <thead class="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
                    <tr>
                        <th class="px-4 py-3 text-left">Matric</th>
                        <th class="px-4 py-3 text-left">Name</th>
                        <th class="px-4 py-3 text-left">Course</th>
                        <th class="px-4 py-3 text-left">Lecturer</th>
                        <th class="px-4 py-3 text-left">Company Supervisor</th>
                        <th class="px-4 py-3 text-left">Internship</th>
                        <th class="px-4 py-3 text-left">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white text-slate-700">
                    @forelse($students as $student)
                        <tr>
                            <td class="px-4 py-4">{{ $student->matric_no }}</td>
                            <td class="px-4 py-4">{{ $student->name }}</td>
                            <td class="px-4 py-4">{{ $student->course }}</td>
                            <td class="px-4 py-4">{{ optional($student->lecturer)->name ?? 'Unassigned' }}</td>
                            <td class="px-4 py-4">
                                @if($student->supervisor)
                                    {{ $student->supervisor->name }}
                                    <span class="block text-xs text-slate-400">{{ $student->supervisor->company_name }}</span>
                                @else
                                    <span class="text-slate-400">Unassigned</span>
                                @endif
                            </td>
                            <td class="px-4 py-4">
                                @if($student->internship_start)
                                    {{ $student->internship_start->format('d M Y') }}
                                    <span class="block text-xs text-slate-400">{{ $student->internship_weeks ?: 14 }} weeks &middot; {{ implode(', ', array_map(fn ($day) => \App\Services\WeekPlanner::DAY_NAMES[$day], \App\Services\WeekPlanner::parseDays($student->working_days))) }}</span>
                                @else
                                    <span class="rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-800">Not set</span>
                                @endif
                            </td>
                            <td class="px-4 py-4">
                                <div class="flex flex-wrap gap-2">
                                    <a href="/admin/students/{{ $student->student_id }}/edit" class="inline-flex items-center rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-semibold text-slate-900 transition hover:bg-amber-600">
                                        Edit
                                    </a>
                                    <form action="/admin/students/{{ $student->student_id }}" method="POST" class="inline" onsubmit="return confirm('Delete this student and all of their logbook entries?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="inline-flex items-center rounded-lg bg-rose-500 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-rose-600">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-4 py-6 text-center text-slate-500">No students found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="flex justify-end">
        {{ $students->links() }}
    </div>
</div>
@endsection