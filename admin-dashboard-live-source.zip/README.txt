﻿Admin dashboard live source bundle generated from the current project state. Includes controllers, models, services, views, routes, CSS/JS, config, and migrations for feature work and UI changes.

Generated: 2026-10-27T22:55:40.9965430+08:00
