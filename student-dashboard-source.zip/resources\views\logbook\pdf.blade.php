<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Logbook - {{ $student->name }}</title>
    <style>
        @page { margin: 28px 34px; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #1f2937; }
        h1 { margin: 0; color: #1d4ed8; font-size: 20px; }
        h2 { margin: 0 0 8px; font-size: 14px; color: #1e3a8a; }
        .header { border-bottom: 2px solid #2563eb; margin-bottom: 16px; padding-bottom: 10px; }
        .muted { color: #64748b; }
        .entry { page-break-inside: avoid; border: 1px solid #cbd5e1; border-radius: 5px; margin: 0 0 14px; padding: 12px; }
        .meta { margin: 0 0 10px; line-height: 1.6; }
        .description { white-space: pre-wrap; line-height: 1.5; }
        .section { margin-top: 10px; }
        .section-title { margin-bottom: 4px; font-weight: bold; }
        .feedback { border-left: 2px solid #cbd5e1; margin: 6px 0; padding-left: 8px; }
        .footer { border-top: 1px solid #e2e8f0; color: #64748b; font-size: 9px; margin-top: 18px; padding-top: 7px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Student Logbook</h1>
        <div class="muted">Generated {{ now()->format('d F Y H:i') }}</div>
    </div>

    <p>
        <strong>Student:</strong> {{ $student->name }}<br>
        <strong>Matric number:</strong> {{ $student->matric_no }}<br>
        <strong>Course:</strong> {{ $student->course ?: 'N/A' }}
    </p>

    @forelse($logbooks as $logbook)
        <section class="entry">
            <h2>Week {{ $logbook->week_no }}</h2>
            <p class="meta">
                <strong>Activity date:</strong> {{ $logbook->activity_date ? \Carbon\Carbon::parse($logbook->activity_date)->format('d F Y') : 'N/A' }}<br>
                <strong>Lecturer status:</strong> {{ $logbook->status ?: 'Pending' }}<br>
                <strong>Supervisor status:</strong> {{ $logbook->supervisor_status ?: 'Pending' }}
            </p>
            <div class="description">{{ $logbook->description }}</div>

            @if($logbook->attachments->isNotEmpty())
                <div class="section">
                    <div class="section-title">Attachments</div>
                    @foreach($logbook->attachments as $attachment)
                        <div>{{ $attachment->file_name }}</div>
                    @endforeach
                </div>
            @endif

            @if($logbook->feedbacks->isNotEmpty())
                <div class="section">
                    <div class="section-title">Feedback</div>
                    @foreach($logbook->feedbacks->sortBy('feedback_date') as $feedback)
                        @php
                            $isSupervisorFeedback = ! empty($feedback->supervisor_id);
                            $reviewer = $isSupervisorFeedback
                                ? (optional($feedback->supervisor)->name ?? 'Supervisor')
                                : (optional($feedback->lecturer)->name ?? 'Lecturer');
                        @endphp
                        <div class="feedback">
                            <strong>{{ $reviewer }}</strong>
                            <span class="muted"> - {{ $feedback->feedback_date ? \Carbon\Carbon::parse($feedback->feedback_date)->format('d M Y') : '' }}</span><br>
                            {{ $feedback->comment }}
                        </div>
                    @endforeach
                </div>
            @endif
        </section>
    @empty
        <p class="muted">No logbook entries have been submitted.</p>
    @endforelse

    <div class="footer">Smart eLogBook System</div>
</body>
</html>
