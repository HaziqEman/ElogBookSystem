<?php

namespace App\Http\Controllers;

use App\Models\Logbook;
use App\Models\Student;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class LogbookPdfController extends Controller
{
    public function student()
    {
        return $this->downloadFor(Auth::guard('student')->user());
    }

    public function lecturer($studentId)
    {
        $lecturer = Auth::guard('lecturer')->user();
        $student = Student::where('lecturer_id', $lecturer->lecturer_id)->findOrFail($studentId);

        return $this->downloadFor($student);
    }

    public function supervisor($studentId)
    {
        $supervisor = Auth::guard('supervisor')->user();
        $student = Student::where('supervisor_id', $supervisor->supervisor_id)->findOrFail($studentId);

        return $this->downloadFor($student);
    }

    private function downloadFor(Student $student)
    {
        $logbooks = Logbook::with([
            'attachments',
            'feedbacks.lecturer',
            'feedbacks.supervisor',
        ])
            ->where('student_id', $student->student_id)
            ->orderBy('activity_date')
            ->orderBy('logbook_id')
            ->get();

        return Pdf::loadView('logbook.pdf', compact('student', 'logbooks'))
            ->setPaper('a4')
            ->download($this->filename($student));
    }

    private function filename(Student $student): string
    {
        $identifier = Str::slug($student->matric_no ?: (string) $student->student_id);

        return 'logbook-'.$identifier.'-'.now()->format('Ymd').'.pdf';
    }
}
